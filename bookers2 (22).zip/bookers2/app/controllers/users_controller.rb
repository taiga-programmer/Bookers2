class UsersController < ApplicationController
  def index
    @users = User.all
    @user = current_user
    @books = Book.all
    @book = Book.new
  end

  def show
    @user = User.find(params[:id])
    @book_new = Book.new
    @books = @user.books.all
  end

  def edit
    @user = User.find(params[:id])
    if @user != current_user  # ログインユーザーでなければ
      redirect_to user_path(current_user.id)  # ログインユーザー画面へリダイレクト
    end
  end
  
  def update
    @user = User.find(params[:id])
    @user.update(user_params)
    if @user.save
      flash[:notice] = 'You have updated user successfully!'
      redirect_to user_path(@user.id)
    else
      render :edit
    end
  end
  
  def user_params
    params.require(:user).permit(:name, :profile_image, :introduction)
  end
end
