# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'abdf6a23e1ad1aedeec51520ae77c5af1c3c3a26d53ac8c8528dcfdfa51d926f752b0c0ec1c12d6aee8663508477726eae887d1456c96bddf1cd85302f4f2360'